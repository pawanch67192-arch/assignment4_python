# Weather Data Visualizer

Assignment folder structure generated.