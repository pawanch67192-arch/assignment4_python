# Weather Report
Daily, monthly and yearly weather patterns analyzed.

## Key Insights
- Daily average temperature: 21.10
- See PNG images for all plots.
